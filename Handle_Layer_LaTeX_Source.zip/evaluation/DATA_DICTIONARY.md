# Prospective Handle Layer evaluation

These are empty collection templates, not observations. Do not fill missing measurements with zero. Preserve missing, not applicable, and measured zero as distinct states. All IDs should be pseudonymous. Store source text and private material in an authorized repository and use references here; a research log must not become an uncontrolled duplicate of confidential records.

## Before data collection

1. Define task strata, objective acceptance criteria, required information, material-error categories, and time budgets. Have domain reviewers approve them without seeing which arm produced an output.
2. Document the legacy condition exactly. Name model versions and memory loading rules. An unavailable historical implementation is a reconstruction, not the original baseline.
3. Randomize comparable tasks across legacy memory (`L`), optimized native memory (`N`), and handles (`H`), holding model, tools, evidence access, and governance fixed. Avoid teaching a participant the answer by making them repeat the same task in another arm. Distinguish a single-user study from population research.
4. Prespecify primary outcomes, inferiority margins, minimum relevant effects, sample-size analysis, missing-data treatment, clustering, and multiple-comparison adjustment. Label exploratory analyses.
5. Obtain appropriate consent and organizational review before collecting participant or workplace data. Restrict access, define retention, and separate identifiers from outcome logs.

## Task log

- One row per assigned task attempt under a study arm. `task_id` is unique within `study_id`; assign related instances a `matched_block_id`.
- `memory_condition`: `L`, `N`, or `H`; `governance_condition`: documented existing or enhanced policy.
- `cache_condition`: cold, warm, mixed, or unknown; record actual usage categories in the provider export linked to the task.
- `status`: accepted, rejected, timed_out, blocked, abandoned, or still_running. Keep every assigned task. `ended_at_utc` is blank for a running task.
- `first_pass_accepted`: 0/1 under the fixed rubric before human editing; `final_accepted`: 0/1 at the evaluation cutoff. A blocked task is not silently dropped.
- Human-time columns are mutually exclusive active labour, in minutes. Context restoration is rebuilding objectives, constraints, decisions, or source identity; correction is repairing output. Include state maintenance and allocate shared setup to all tasks according to a declared rule. Do not count unattended runtime as labour.
- `elapsed_minutes`: wall time to terminal status/cutoff. Distinguish censored tasks from time to acceptance. State whether external waiting is included.
- `api_cost_usd`: all associated model calls, retries, and billed cache activity. `other_nonlabor_cost_usd`: retrieval, storage, tooling, and allocated setup fees not already in the API total. Do not include action totals again; action rows partition or explain these totals.
- If monetizing human effort, apply a declared wage/overhead assumption once to the summed human hours, and report the assumption separately. API savings and labour savings are different outcomes.
- `operational_energy_kwh`: all attributed measured operational energy for the stated boundary. If unavailable, leave blank. Put estimates in a separate dataset labeled with assumptions; never derive measured energy from price.
- `energy_measurement_method`: meter identifier or attribution procedure. `energy_boundary`: components, facility-overhead treatment, time interval, and whether retrieval and customer devices are included.
- Required items are specified before outputs. `required_items_correct <= required_item_count`. Count missing information as not correctly addressed; do not change the target after observing the response.
- `subjective_effort_rating`: use a fixed, declared scale, collected separately from timing. This can illuminate perception without replacing measurement.

## Action log

- One row per bounded action with an auditable purpose. `action_type` may be model_call, retrieval, search, edit, verification, checkpoint, human_review, or other documented type.
- Fingerprints help retrieve candidates for review. They do not establish a semantic duplicate by themselves.
- `source_ids_and_versions` and `input_fingerprint` must preserve distinctions in entities, dates, relevant instructions, and input revisions.
- `prior_adequate_result_id` points to the earlier satisfactory result, not merely to any similar attempt. `prior_result_accessible` records whether the workflow could use it at the time.
- `repeat_class`: not_repeat, avoidable_duplicate, necessary_refresh, independent_verification, failed_attempt_retry, authorization_change, new_requirement, or uncertain.
- `avoidable_duplicate` is 1 only after adjudication. Use 0 for an adjudicated other class and blank for uncertain/unreviewed. Report the unreviewed proportion; do not classify it automatically as efficient work.
- `repeat_reason` records the purpose known at execution. Reviewers must not penalize required verification merely because it returned the same answer.
- A mixed-purpose action is not wholly charged as duplicate unless its avoidable portion is separately attributable. Document partial allocation or leave it unallocated and disclose this limitation.
- `action_cost_usd`, `action_energy_kwh`, and `active_human_minutes` are partitions of task totals or explicitly reconciled allocations. Do not add task and action totals together. Concurrent energy requires a stated allocation rule.
- Human restoration minutes already counted at task level should not be charged again from checkpoint records.

## Claim and citation logs

- `output_stage`: first_pass or final. Evaluate them separately to expose human repair costs.
- Segment outputs into atomic claims using a fixed annotation policy. `is_verifiable` and `is_evidence_required` are 0/1. Capture every verifiable claim, not only easy ones.
- `correctness_label`: correct, incorrect, unresolved, or not_applicable. Report all counts. Conservative factual accuracy is correct divided by all emitted verifiable claims, including unresolved claims in the denominator. Evaluate appropriate uncertainty separately; an unresolved statement is not automatically a demonstrated falsehood.
- `required_item_ids` links a claim to the fixed requirement register. Accuracy does not replace requirement coverage.
- `claim_supported_by_evidence_set`: supported, partial, unsupported, or unresolved, judging the entire relevant evidence set. Support is distinct from truth; an obsolete or unreliable source may accurately be quoted yet still mislead.
- Citation rows hold one claim–citation link. `support_label`: supported, partial, unsupported, or inaccessible. A live URL is not enough. For strict precision, numerator is supported links; denominator is all checked required links, with inaccessible and partial counts separately visible.
- Evidence coverage is the number of claims requiring evidence that are fully supported by their cited evidence set divided by all claims requiring evidence. No citation gives no support; empty citation sets are not omitted.
- `error_type`: factual, numerical, entity_confusion, wrong_date, contradiction, unsupported_inference, correction_recurrence, or a declared domain-specific class. Maintain severity independently of error count.
- Double-code a sample and retain both original decisions in the secure adjudication record; resolve disagreements with a third review or documented consensus. Report reviewer agreement and unresolved disputes.

## Checkpoints and corrections

- For every planned restart, define required state items before resumption. `required_state_items_retained` counts correct retained items without user reconstruction.
- To measure correction recurrence, use one row per eligible prior correction per checkpoint (repeat checkpoint summary fields without summing them repeatedly). Eligibility means the corrected issue matters at that checkpoint.
- `corrected_error_recurred`: 0/1 only when relevant and adjudicated; blank otherwise. The denominator is eligible opportunities, not all turns or all historic corrections.
- Sum restoration time once per unique checkpoint, and reconcile it with the task log.

## Reporting

Report H–L and H–N separately. For each condition include all assigned tasks, acceptance, active human hours, accepted work per human hour, elapsed-time results with failures/censoring, first-pass and final accuracy, requirement coverage, context restoration, correction recurrence, duplicate action counts, duplicate cost/energy shares, and total cost and energy at a declared boundary.

Duplicate shares must accompany absolute duplicate actions and resources per assigned and accepted task. A share can fall just because other actions grew. Relative reduction is `1 - handle/baseline` for positive, comparable baseline values. With a zero baseline use the absolute difference. Do not report a percentage when the denominator is missing or zero.

Separate percentage points from relative changes and time reduction from productivity gain. Use prespecified task/participant/project clustering for confidence intervals. Do not calculate an apparent global TWh saving from a small pilot, customer invoice, or unvalidated token-to-watt coefficient.

Includes confirmed and circumstantial data. Not financial advice.
