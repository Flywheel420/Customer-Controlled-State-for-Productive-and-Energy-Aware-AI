"""Reproduce the paper's figures and arithmetic from the supplied data.

No API calls or model experiments are performed. Published measurements,
institutional estimates, tariff calculations and assumptions stay separate.
"""
from pathlib import Path
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = Path(__file__).resolve().parent
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'axes.labelsize': 9, 'axes.titlesize': 10, 'axes.titleweight': 'bold',
    'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.dpi': 300,
})
BLUE, TEAL, ORANGE, GRAY, LIGHT = '#285477', '#247B75', '#B66B2B', '#7C8792', '#E9EEF1'

def save(fig, name):
    fig.savefig(FIG / f'{name}.pdf', bbox_inches='tight')
    fig.savefig(FIG / f'{name}.png', bbox_inches='tight', dpi=180)
    plt.close(fig)

# Figure 1: distinct scopes and units, intentionally separate axes.
fig, axes = plt.subplots(1, 2, figsize=(6.8, 3.55), gridspec_kw={'width_ratios':[1, 1.3]})
ax = axes[0]
ax.bar([0, 1], [485, 950], color=[BLUE, LIGHT], edgecolor=BLUE, width=.57)
ax.patches[1].set_hatch('///')
ax.set_xticks([0, 1], ['2025\nestimate', '2030\nprojection'])
ax.set_ylabel('Electricity (TWh/year)')
ax.set_ylim(0, 1100)
ax.set_title('(a) All data centres', loc='left')
for x, y in enumerate([485, 950]): ax.text(x, y+30, str(y), ha='center', fontsize=10)
ax.grid(axis='y', alpha=.16); ax.set_axisbelow(True)
ax = axes[1]
ax.bar(0, .10, color=GRAY, width=.5, label='Narrow approach')
bottom=0
for val, label, color in [(0.14,'Active accelerators',BLUE),(.06,'CPU and DRAM',TEAL),(.02,'Idle machines',ORANGE),(.02,'Facility overhead',LIGHT)]:
    ax.bar(1, val, bottom=bottom, color=color, width=.5, edgecolor='white', linewidth=.5, label=label)
    bottom += val
ax.text(0,.109,'0.10',ha='center'); ax.text(1,.249,'0.24',ha='center')
ax.set_ylim(0,.29); ax.set_yticks([0,.1,.2])
ax.set_xticks([0,1],['Narrow\nselected sample','Comprehensive\nfleet sample'])
ax.set_ylabel('Median prompt energy (Wh)')
ax.set_title('(b) Gemini Apps, May 2025',loc='left')
ax.legend(loc='upper center',bbox_to_anchor=(.52,-.26),ncol=2,frameon=False,columnspacing=1)
ax.grid(axis='y',alpha=.16); ax.set_axisbelow(True)
fig.subplots_adjust(wspace=.5,bottom=.29,top=.88)
save(fig,'fig1_evidence_boundaries')

# Figure 2: published task-specific means, not matched substitutes.
with (ROOT/'data/task_energy.csv').open() as f: tasks=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(6.8,3.9))
means=np.array([float(r['mean_kwh_per_1000']) for r in tasks])
ys=np.arange(len(tasks))
ax.barh(ys,means,color=BLUE,height=.66)
ax.set_yticks(ys,[r['task'] for r in tasks]); ax.invert_yaxis()
ax.set_xscale('log'); ax.set_xlim(.001,8)
ax.set_xlabel('Energy (kWh per 1,000 inferences; logarithmic scale)')
ax.set_xticks([.001,.01,.1,1],['0.001','0.01','0.1','1'])
for y,val in zip(ys,means): ax.text(val*1.12,y,f'{val:.3f}',va='center',fontsize=8)
ax.grid(axis='x',which='major',alpha=.2); ax.set_axisbelow(True)
ax.set_title('Task-specific benchmark means (Luccioni et al., Table 2)',loc='left')
fig.tight_layout(); save(fig,'fig2_task_energy')

# Figure 3: deterministic tariff arithmetic, not observed invoices or energy.
with (ROOT/'data/pricing_snapshot.csv').open() as f:
    rates={r['token_category']:float(r['usd_per_million'])/1e6 for r in csv.DictReader(f)}
N,B,H,S,O=20,20000,2000,1000,1000
def cost(prefix, retrieved, cached):
    return {
       'uncached_input': (N*(S+retrieved)+(0 if cached else N*prefix))*rates['input_uncached'],
       'cache_write': (prefix if cached else 0)*rates['cache_write'],
       'cache_read': ((N-1)*prefix if cached else 0)*rates['cache_read'],
       'output': N*O*rates['output'],
    }
scenarios=[('Full prefix\nno caching',cost(B,0,False)),('Full prefix\ncached',cost(B,0,True)),('Handle + retrieval\n1k retrieved/job',cost(H,1000,True)),('Handle + retrieval\n4k retrieved/job',cost(H,4000,True))]
totals=np.array([sum(parts.values()) for _,parts in scenarios])
fig,ax=plt.subplots(figsize=(6.8,3.6))
base=np.zeros(len(scenarios))
for key,label,color in [('uncached_input','Uncached input',BLUE),('cache_write','Cache write',ORANGE),('cache_read','Cache reads',TEAL),('output','Output',GRAY)]:
    val=np.array([parts[key] for _,parts in scenarios]); ax.bar(range(4),val,bottom=base,label=label,color=color,width=.59); base+=val
for x,total in enumerate(totals):ax.text(x,total+.027,f'${total:.4f}',ha='center',fontsize=9)
ax.set_xticks(range(4),[r[0] for r in scenarios]);ax.set_ylim(0,1.24)
ax.set_ylabel('API charge for 20 jobs (USD)')
ax.set_title('Worked tariff example: identical billed output, different context',loc='left')
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.24),ncol=4,frameon=False,columnspacing=.8)
ax.grid(axis='y',alpha=.17);ax.set_axisbelow(True)
fig.subplots_adjust(bottom=.29,top=.88);save(fig,'fig3_cache_economics')

# Figure 4: model-derived feasible interval; no measured demand elasticity.
d,s,g_example=.1,.35,1.12
growth=np.linspace(0,.8,401);g=1+growth
lower=1/(1-d)-1;upper=1/(1-s)-1
fig,ax=plt.subplots(figsize=(6.8,3.5))
ax.axvspan(lower,upper,color=TEAL,alpha=.10)
ax.plot(growth,g*(1-d)*100,color=BLUE,lw=2,label='Provider revenue')
ax.plot(growth,g*(1-s)*100,color=ORANGE,lw=2,label='Total operational energy')
ax.axhline(100,color=GRAY,lw=1,ls='--',label='Baseline = 100')
ax.axvline(lower,color=TEAL,lw=.9,ls=':');ax.axvline(upper,color=TEAL,lw=.9,ls=':')
ax.scatter([.12,.12],[100.8,72.8],c=[BLUE,ORANGE],s=28,zorder=4)
ax.annotate('Example: revenue 100.8',xy=(.12,100.8),xytext=(.18,92),fontsize=8,color=BLUE,arrowprops={'arrowstyle':'-','color':BLUE,'lw':.6})
ax.annotate('Energy 72.8',xy=(.12,72.8),xytext=(.20,68),fontsize=8,color=ORANGE,arrowprops={'arrowstyle':'-','color':ORANGE,'lw':.6})
ax.text((lower+upper)/2,148,'Revenue preserved AND\nabsolute energy reduced',ha='center',fontsize=9,color=TEAL)
ax.text(lower,57,'11.1%',ha='center',fontsize=8,color=TEAL);ax.text(upper,57,'53.8%',ha='center',fontsize=8,color=TEAL)
ax.set_xlim(0,.8);ax.set_ylim(52,169);ax.xaxis.set_major_formatter(PercentFormatter(1))
ax.set_xlabel('Growth in accepted, comparable jobs');ax.set_ylabel('Index (baseline = 100)')
ax.set_title('Analytical scenario: price/job -10%; energy/job -35%',loc='left')
ax.legend(loc='lower right',frameon=False,fontsize=8)
ax.grid(alpha=.13);fig.tight_layout();save(fig,'fig4_alignment_region')

native_total=totals[1]
threshold=(B-H)*(rates['cache_write']+(N-1)*rates['cache_read'])/(N*rates['input_uncached'])
computed={
 'type':'deterministic calculations; not experimental outcomes',
 'pricing_assumptions':{'jobs':N,'archive_prefix_tokens':B,'handle_prefix_tokens':H,'new_task_tokens':S,'billed_output_tokens':O,'retrieval_other_fees':0,'rewrite_and_verification_fees':0,'cache_hits_after_initial_write':'all'},
 'cache_scenarios':[{'scenario':name,'parts_usd':parts,'total_usd':sum(parts.values())} for name,parts in scenarios],
 'retrieval_break_even_tokens_per_job':threshold,
 'low_retrieval_savings_vs_native_pct':(1-totals[2]/native_total)*100,
 'high_retrieval_cost_increase_vs_native_pct':(totals[3]/native_total-1)*100,
 'alignment_assumptions':{'baseline_jobs':100,'new_jobs':112,'old_price':1,'new_price':.9,'old_avoidable_cost':.6,'new_avoidable_cost':.4,'old_energy_per_job':1,'new_energy_per_job':.65},
 'alignment_outcomes':{'old_revenue':100,'new_revenue':100.8,'old_contribution':40,'new_contribution':56,'old_energy':100,'new_energy':72.8,'energy_reduction_pct':27.2,'min_growth_pct':lower*100,'energy_break_even_growth_pct':upper*100},
 'illustrative_global_fraction':.2*.4*.5,
}
(ROOT/'data/derived_results.json').write_text(json.dumps(computed,indent=2)+'\n')
with (ROOT/'data/derived_costs.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['scenario','uncached_input_usd','cache_write_usd','cache_read_usd','output_usd','total_usd'])
    for name,parts in scenarios:w.writerow([name.replace('\n',' '),*parts.values(),sum(parts.values())])
print(json.dumps({'figure_count':4,'cost_totals_usd':totals.tolist(),'retrieval_break_even_tokens':threshold,'energy_reduction_pct':27.2}))
