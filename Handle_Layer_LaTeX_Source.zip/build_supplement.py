"""Build Supplement S1 locally, without compiling, publishing, or model calls."""

from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


def main():
    root = Path(__file__).resolve().parent
    top_level = (
        "Handle_Layer_Energy_Paper.tex", "references.bib", "README.md",
        "HANDOFF.md", "SUPPLEMENT_INDEX.md", "source_ledger.csv",
        "generate_figures.py", "build_supplement.py",
    )
    paths = [root / name for name in top_level]
    for folder in ("data", "figures", "evaluation", "examples"):
        paths.extend(
            p for p in (root / folder).rglob("*")
            if p.is_file() and "__pycache__" not in p.parts
            and not any(part.startswith(".") for part in p.relative_to(root).parts)
        )
    for path in paths:
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"Expected a regular source file: {path}")
    payload = {
        p.relative_to(root).as_posix(): p.read_bytes()
        for p in sorted(paths)
    }
    checksums = "".join(
        f"{sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(payload.items())
    ).encode("utf-8")
    manifest = root / "SHA256SUMS.txt"
    manifest_candidate = root / "SHA256SUMS.txt.candidate"
    manifest_candidate.write_bytes(checksums)
    manifest_candidate.replace(manifest)
    payload[manifest.name] = checksums
    archive = root / "Handle_Layer_LaTeX_Source.zip"
    candidate = root / "Handle_Layer_LaTeX_Source.zip.candidate"
    with ZipFile(candidate, "w", compression=ZIP_DEFLATED) as output:
        for name, data in sorted(payload.items()):
            info = ZipInfo(name, date_time=(2026, 8, 30, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, data)
    with ZipFile(candidate) as result:
        if result.testzip() is not None:
            raise ValueError("Archive integrity check failed")
        for name, data in payload.items():
            if result.read(name) != data:
                raise ValueError(f"Archive content mismatch: {name}")
    candidate.replace(archive)
    print(f"Built {archive.name}: {len(payload)} files, {archive.stat().st_size} bytes.")


if __name__ == "__main__":
    main()
