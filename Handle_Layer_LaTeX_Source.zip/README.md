# Customer-Controlled State for Productive and Energy-Aware AI

Research position paper and analytical framework, 30 August 2026.

Provisional byline supplied for this draft: S. Jack, K. Lazerus, T. Speedman, J. Portnoy, and L. Grossman. Affiliations, contributions, corresponding author, funding, conflicts, and practitioner relationship have not been confirmed.

This package contains an academic-style LaTeX manuscript, four reproducible figures, a bibliography, a numerical evidence ledger, and empty evaluation templates. It is an unsubmitted draft, not a peer-reviewed publication or an empirical validation of the proposed Handle Layer. Practitioner-reported improvements motivate a comparison of legacy memory, optimized native state, and explicit handles; no quantitative result for that comparison is invented.

## Reader access and citation

This is **Supplement S1**, release **S1-2026-08-30-1**. Start with [SUPPLEMENT_INDEX.md](SUPPLEMENT_INDEX.md) for clickable links to every supporting file. No code execution is needed to inspect the supplied files. The distributed PDF embeds the same ZIP as a file attachment and provides a reader map in Appendix B. Save and extract the attachment in a compatible desktop PDF viewer; if your viewer does not expose attachments, use the separate ZIP supplied alongside the paper. Do not disable security controls to open a blocked attachment.

The draft has no public repository URL or DOI. Before submission, the authors should approve a release, confirm authorship and disclosures, check redistribution rights, and choose appropriate licenses. A public GitHub repository can provide file-by-file browsing; a Zenodo archive can provide a persistent citation for a specific release. Upload individual key files as well as the ZIP where useful. Public distribution of this research supplement is separate from the private customer repositories described in the proposed protocol.

Use a version-specific DOI for the supplement used in the paper, with the path and relevant row, field, or section for a particular item. Before a DOI exists, refer internally to “Supplement S1, release S1-2026-08-30-1”; do not invent a DOI, URL, or completed repository citation. Continue citing the underlying studies separately. Publishing a supplement does not establish peer review, author approval, or empirical validation.

Publication-workflow references: [GitHub guidance on citing repositories](https://docs.github.com/en/repositories/archiving-a-github-repository/referencing-and-citing-content), [Zenodo DOI versioning](https://zenodo.org/help/versioning), and [Adobe attachment access](https://helpx.adobe.com/acrobat/desktop/edit-documents/use-links-and-attachments/open-attachment.html). These describe distribution capabilities, not evidence for the Handle Layer.

## Contents

- `SUPPLEMENT_INDEX.md`: reader navigation, file descriptions, and citation guidance.
- `build_supplement.py` and `SHA256SUMS.txt`: source-package builder and payload checksums.
- `HANDOFF.md`: current decisions, completed edits, evidence limits, and instructions for continuing the manuscript.
- `Handle_Layer_Energy_Paper.tex`: manuscript source.
- `references.bib`: 24 checked source records.
- `figures/`: vector PDF and PNG figures.
- `generate_figures.py`: reproduces figures and analytical calculations; makes no network or model calls.
- `data/published_measurements.csv`: selected institutional and research figures, with evidence class and limitations.
- `data/task_energy.csv`: published task-specific means and standard deviations from Luccioni et al., Table 2.
- `data/pricing_snapshot.csv`: official GPT-5.6 Terra standard short-context tariff observed 30 August 2026.
- `data/derived_results.json` and `data/derived_costs.csv`: calculations from explicit assumptions, not observed outcomes.
- `source_ledger.csv`: source URLs, exact versions or locators, and intended use.
- `evaluation/`: empty task, action, claim, citation, and checkpoint logs plus a data dictionary covering productivity, accuracy, restoration effort, and duplicate work. No participant data are included.
- `examples/private_project_recovery.md`: private storage and ledger layout, an illustrative corrected handle, safe checkpoint replacement, and a proposed offline restore sequence. This is a design example, not deployed software or measured test results.

## Build

Requires a LaTeX distribution with pdfLaTeX, BibTeX and latexmk, plus standard article, Latin Modern, geometry, microtype, amsmath, graphicx, booktabs, tabularx, enumitem, caption, fancyhdr, natbib, hyperref and attachfile2 packages.

The figure PDFs are included, so Python is not needed to compile a manuscript without an embedded supplement. To reproduce the distributed PDF with its attachment, first build the ZIP using Python 3's standard library, then compile:

```sh
python3 build_supplement.py
latexmk -pdf -interaction=nonstopmode -halt-on-error Handle_Layer_Energy_Paper.tex
```

The builder excludes compiled manuscripts and the ZIP itself, avoiding recursive packaging. Rebuild the ZIP after any source change and before recompiling. A plain LaTeX build without the ZIP uses an availability note that directs readers to the separate supplement. In Overleaf, a plain source upload may therefore compile without the embedded ZIP; supply the separate supplement to readers as well.

To regenerate figures and numerical outputs, install Python 3 with NumPy and Matplotlib, then run:

```sh
python3 generate_figures.py
python3 build_supplement.py
latexmk -pdf -interaction=nonstopmode -halt-on-error Handle_Layer_Energy_Paper.tex
```

The tested environment used Python 3, NumPy, Matplotlib, TeX Live 2023, and latexmk 4.83. No special font download or online API is required. In Overleaf, upload the package, select `Handle_Layer_Energy_Paper.tex` as the main document, and use pdfLaTeX.

## Search and evidence method

Targeted web searches were performed on 30 August 2026. Search terms included:

- IEA Key Questions on Energy and AI 2026.
- Measuring the environmental impact of delivering AI at Google Scale.
- Lost in the Middle TACL 2024.
- Power Hungry Processing Luccioni Jernite Strubell.
- RouteLLM Learning to Route LLMs with Preference Data.
- Efficient Memory Management PagedAttention 2023.
- MemGPT Towards LLMs as Operating Systems.
- Green Algorithms Quantifying the Carbon Footprint of Computation.
- The Rebound Effect and Energy Efficiency Policy.
- OpenAI prompt caching pricing GPT-5.6.
- Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity.
- The Impact of AI on Developer Productivity Evidence from GitHub Copilot.
- Evaluating Verifiability in Generative Search Engines.

For the revised implementation profile, official Git, GitHub, and AWS documentation was consulted for repository cloning, conditional reference updates, offline bundles, LFS pointer scope, sensitive history, and idempotent retries. These engineering sources support capabilities and limitations, not measured Handle Layer benefits.

Official provider pages were opened for price and capability claims. Versioned research manuscripts were used where possible; publisher and institutional pages were used to check publication identities and dates. This was a targeted narrative review, not a systematic search with exhaustive coverage. Third-party summaries claiming universal routing savings were not used to support quantitative conclusions.

The original papers and underlying raw experimental logs were not independently replicated. Only short numerical transcriptions, original calculations, original figure renderings, and bibliographic metadata are bundled; source publications remain available at their cited URLs.

## Reproduction notes and limits

1. Figure 1 combines different populations on separate axes. IEA values cover all data centres. Google's prompt values are product-specific medians under different measurement and sampling methods. They must not be multiplied into a global consumption estimate.
2. Figure 2 plots published benchmark means. Its CSV preserves standard deviations; no confidence intervals are invented. Different tasks and models are not quality-equivalent substitutes. In the source's task-specific experiment, text generation produces ten new tokens and requests are unbatched.
3. Figure 3 is an API tariff calculation for 20 assumed jobs. It includes one initial cache write and 19 full reads, equal output counts, stable prefixes and no extra retrieval/service fees. Additional tool calls, index maintenance, handle writes, validation and human work are excluded. It is neither an actual bill nor an energy measurement.
4. Figure 4 uses explicit hypothetical price, energy and demand assumptions. No measured AI price elasticity is claimed. The zero-fixed-extra-overhead assumption is relaxed algebraically in the manuscript.
5. Public documentation and rates can change. Recheck the source ledger before applying these numbers to a live deployment.
6. Offline recoverability is required in the reference customer implementation. Git is optional and private; no public repository or new hosted service is required. Recovery covers a declared set of locally available files and retained revisions, not an assumption that every linked source is cached.
7. The update preserves the four numerical figures and their assumptions. New backup, storage, synchronization, and supervision overhead must be counted in any deployment evaluation.

## Before journal submission

The submitting authors should complete and confirm the supplied author list and affiliations; complete funding and conflict-of-interest disclosures; adapt the manuscript to the selected journal; verify references and relevant licenses; and review the AI-assistance disclosure. No additional author identities, affiliations, journal acceptance, DOI, funding claims, or peer-review status have been invented. No journal submission, remote-repository creation, or external communication has been made.

Includes confirmed and circumstantial data. Not financial advice.
