# Supplement S1: reader index

**Release:** S1-2026-08-30-1, 30 August 2026. **Status:** unpublished working-draft supplement. No public repository URL or DOI has been assigned. The authorship is provisional: affiliations, contributions, funding, conflicts, author approval, and the practitioner relationship remain unconfirmed.

This supplement supports *Customer-Controlled State for Productive and Energy-Aware AI*. It contains published-value transcriptions, deterministic calculations, figure code, and a proposed evaluation. It contains no new Handle Layer experimental observations.

Extract the ZIP before following these relative links. They also work when the extracted package is viewed in a repository that renders Markdown. CSV files can be opened in a spreadsheet or text editor; JSON, Markdown, Python, BibTeX, and LaTeX files are readable as text. PDFs and PNGs provide ready-to-view figures. Inspection does not require running the code.

## Start here

| File | Contents |
|---|---|
| [README.md](README.md) | Access, build instructions, evidence limits, and publication steps. |
| [HANDOFF.md](HANDOFF.md) | Current decisions, corrections, and unresolved work. |
| [Handle_Layer_Energy_Paper.tex](Handle_Layer_Energy_Paper.tex) | Editable manuscript, including Appendix B's reader map. |
| [SHA256SUMS.txt](SHA256SUMS.txt) | Integrity hashes for the payload files, excluding this manifest itself. Hash agreement does not certify truth. |
| [build_supplement.py](build_supplement.py) | Builds the ZIP and checksums from the declared source files; does not publish or make model calls. |

## Evidence and numerical inputs

| File | What it supports |
|---|---|
| [source_ledger.csv](source_ledger.csv) | Source identities, versions, locators, URLs, evidence classes, and interpretation limits. |
| [references.bib](references.bib) | The manuscript's 24 bibliographic records. |
| [data/published_measurements.csv](data/published_measurements.csv) | Selected published or institutional values, including Figure 1's inputs. |
| [data/task_energy.csv](data/task_energy.csv) | Published task-energy means and standard deviations used in Figure 2. |
| [data/pricing_snapshot.csv](data/pricing_snapshot.csv) | Recorded tariff inputs for the illustrative cache comparison. |
| [data/derived_costs.csv](data/derived_costs.csv) | Calculated API charges by scenario for Figure 3; not measured customer bills. |
| [data/derived_results.json](data/derived_results.json) | Calculated thresholds and hypothetical alignment outputs for Figures 3 and 4. |

## Figures and reproducibility

| Figure | Viewable files | Interpretation |
|---|---|---|
| 1: evidence boundaries | [PDF](figures/fig1_evidence_boundaries.pdf), [PNG](figures/fig1_evidence_boundaries.png) | Different populations and measurement boundaries; not a common energy denominator. |
| 2: task energy | [PDF](figures/fig2_task_energy.pdf), [PNG](figures/fig2_task_energy.png) | Published task-specific benchmark means; not current commercial-assistant estimates. |
| 3: cache economics | [PDF](figures/fig3_cache_economics.pdf), [PNG](figures/fig3_cache_economics.png) | Conditional tariff arithmetic; not observed savings. |
| 4: revenue and energy | [PDF](figures/fig4_alignment_region.pdf), [PNG](figures/fig4_alignment_region.png) | Hypothetical alignment interval; not measured demand or energy effects. |

[generate_figures.py](generate_figures.py) reproduces these figures and derived calculations. Python dependencies and build commands are in the README. Source studies are cited and linked; their complete papers or experimental logs are not redistributed here.

## Proposed evaluation and implementation example

| File | Purpose |
|---|---|
| [evaluation/DATA_DICTIONARY.md](evaluation/DATA_DICTIONARY.md) | Outcome, logging, and denominator definitions. |
| [evaluation/task_log_template.csv](evaluation/task_log_template.csv) | Assigned tasks, acceptance, human effort, and resource accounting. |
| [evaluation/action_log_template.csv](evaluation/action_log_template.csv) | Actions and adjudication of avoidable duplicate work. |
| [evaluation/claim_log_template.csv](evaluation/claim_log_template.csv) | Claim-level evaluation. |
| [evaluation/citation_log_template.csv](evaluation/citation_log_template.csv) | Claim-to-source support checks. |
| [evaluation/checkpoint_log_template.csv](evaluation/checkpoint_log_template.csv) | Checkpoint and continuity records. |
| [examples/private_project_recovery.md](examples/private_project_recovery.md) | Illustrative private storage, corrected handle, safe checkpoint, and recovery sequence. |

All five CSV logs are empty templates. The recovery sequence is an implementation illustration, not a fault-injection result or a deployed supervisor.

## How to reference a file

For this working draft, write: “Supplement S1, release S1-2026-08-30-1, `data/derived_costs.csv`, scenario `Full prefix cached`.” Use the corresponding filename plus row, field, or section for other items. In the paper, Appendix B provides the supplement cross-reference.

Once an approved public release is deposited, add its version-specific DOI as a bibliographic reference and retain the file locator. A moving repository branch is not sufficient to identify the exact files evaluated. Do not substitute a supplement citation for the original publication supporting a factual claim. Authorship and disclosures must be confirmed before treating the citation metadata as final.

Includes confirmed and circumstantial data. Not financial advice.
