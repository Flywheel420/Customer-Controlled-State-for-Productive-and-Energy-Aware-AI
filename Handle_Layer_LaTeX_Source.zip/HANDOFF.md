# Manuscript handoff

Updated: 30 August 2026. Revision: H02. State: waiting for the user's next instruction.

This file preserves the context needed to continue the manuscript. It is a **handoff file**; the paper's proposed protocol is still called the **Handle Layer**. It is not a substitute for the source package or evidence records.

## Purpose and current status

The user's goal is public benefit, not a new business: improve accepted outputs and productivity, reduce avoidable duplicate work and global energy consumption, lower company costs, and investigate ways to preserve sustainable provider revenue. These are objectives to test, not achieved results.

The manuscript is an **unsubmitted perspective, analytical framework, and proposed evaluation protocol**. It contains a customer implementation profile, 24 references, four figures, six tables, and empty evaluation templates. Appendix B maps the supplementary files. No Handle Layer experiment, billing study, energy measurement, or fault-injection study has been conducted. Practitioner-reported improvements remain qualitative and unverified here.

## Files to preserve and load

| File | Purpose |
|---|---|
| `Handle_Layer_LaTeX_Source.zip` | Portable source package; extract before editing or rebuilding. |
| `Handle_Layer_Energy_Paper.tex` | Current manuscript source. |
| `Handle_Layer_Energy_Paper.pdf` | Current rendered manuscript. |
| `HANDOFF.md` | This continuation record, also included in the source package. |
| `SUPPLEMENT_INDEX.md` | Clickable reader index inside the extracted package. |

Inside the source package, load only what the next task requires: `references.bib` and `source_ledger.csv` for evidence; `data/` and `generate_figures.py` for calculations; `evaluation/` for outcome definitions and empty logs; `examples/private_project_recovery.md` for the illustrative checkpoint/recovery sequence. `README.md` provides build instructions.

For offline continuation, preserve the ZIP as well as this file. A handoff that points to missing sources is not a complete recovery copy. No private Git service, production supervisor, or independent backup system has been deployed as part of this manuscript work.

## Author correction

The supplied provisional authors are **S. Jack, K. Lazerus, T. Speedman, J. Portnoy, and L. Grossman**. S. Jack is the user's explicit correction; do not revert to P. Jack. Unnamed “et al.” has been removed from the byline.

Affiliations, author contributions, corresponding author, funding, conflicts, author approval, and the practitioner's relationship to the authors remain unconfirmed. Do not invent them or treat the byline as verified consent. The provisional-authorship disclosure remains necessary.

## Five edits completed

1. **Abstract:** added the private versioned storage, independent offline recovery copy, and thin-supervisor profile. Explicitly described these as profile requirements, not measured savings.
2. **Authorship:** corrected S. Jack in the title page, PDF metadata, disclosure, and README; removed unnamed co-authors while retaining provisional status.
3. **Table 3:** added offline restore success/failure, recovery time, age of the latest good checkpoint, and lost/repeated actions. Human context-restoration effort remains a separate outcome.
4. **Section 3.1:** linked task/budget state to authoritative reservations before side effects and clarified resource accounting. A rejected commit cannot undo external work. Unknown outcomes must be reconciled before replay.
5. **Last page:** removed the financial-advice disclaimer from the manuscript.

No new figures, mechanisms, or benefit claims were added. The requested manuscript edit list is complete.

## Reader access added after the five edits

Supplement S1 now has release identifier `S1-2026-08-30-1`, a linked file index, an Appendix B reader map, and an availability statement. The distributed PDF embeds the same source ZIP; save and extract it in an attachment-capable viewer, or use the separate ZIP. The package builder uses only Python standard-library modules and writes payload checksums. Rebuild the ZIP before recompiling the PDF after source edits. No public repository, DOI, or journal deposit has been created.

Recommended future publication path: an approved public repository for browsing files and an archived version with a version-specific DOI for citation. The public research supplement is separate from the private customer projects described by the protocol. Author affiliations, contributions, funding, conflicts, approval, and practitioner relationship remain unconfirmed; the provisional-authorship note must stay until those are resolved. Reader access is not permission to publish or to finalize the byline.

## Design decisions to preserve

- Customers control source evidence, corrections, permissions, acceptance criteria, and budget policy; providers control model execution and serving. The state object connects these responsibilities.
- Offline recoverability is required for the reference profile. This does not require local frontier inference or permanent disconnection.
- A private Git repository can store compact project documents, version history, and explicit activity records. Git is one optional backend, not the protocol itself, an authorization system, a truth certificate, or an audited financial ledger.
- Working history is not an independent backup. Preserve a usable recovery copy outside the bot's ability to erase all history, including necessary attachments. Same-disk copies do not protect against disk loss.
- Preserve the last good checkpoint while writing and validating its replacement; publish only if the expected parent remains current. Never delete the only usable old checkpoint first.
- The supervisor remains thin and primarily deterministic. Inspect an empty queue without a model call. Calls require authorized work or a declared freshness check; source text cannot grant permissions.
- `W_v` and `B` reference authoritative task and budget reservations. The trusted execution coordinator enforces them. A handle or Git snapshot alone does not provide atomic reservations for concurrent side effects.

## Measurement and accounting constraints

Compare **L** (documented legacy memory), **N** (optimized native memory/caching/compaction/retrieval), and **H** (customer-controlled handles). Report H–L and H–N separately. Keep model versions, evidence, permissions, and execution/recovery controls comparable; otherwise describe a comparison of whole implementation packages. Separate warm/cold cache conditions and prevent cross-arm answer or cache leakage.

Measure accepted work per active human hour, first-pass and final acceptance, factual accuracy together with requirement coverage, evidence support, correction recurrence, context-restoration effort, offline restore, and adjudicated duplicate work. Include failed and unfinished attempts, review, corrections, and allocated maintenance. Required verification or refresh is not automatically duplicate work. Report absolute repeated actions as well as shares.

Monetary overhead belongs in `C_i`; active human effort belongs in `L_i`. Unattended runtime is not human labour. Local electricity belongs in `E_other` only if it is not already counted in the site-energy terms. Do not count energy or human time twice. Tokens, customer prices, provider costs, electricity, and emissions are distinct quantities.

Extra retrieved tokens increase actual `R`. Additional net handle-specific billed costs lower the break-even `R*` when other assumptions are fixed. The original API tariff threshold is not a total customer cost or energy threshold.

## Numerical anchors and evidence limits

| Item | Current manuscript statement | Limit |
|---|---|---|
| Cache comparison | For 20 synthetic jobs: uncached $1.0800; native cached $0.4060; handle with 1,000 retrieved tokens/job $0.3326; with 4,000, $0.4526. `R* = 2,835` tokens/job. | Deterministic example using the recorded GPT-5.6 Terra tariff snapshot and restrictive reuse/turn assumptions; not a production saving. Verify tariffs before a new planning claim. |
| Revenue/energy alignment | With a 10% price cut and assumed 35% energy-per-job cut, comparable workload growth must be at least 11.1% and below 53.8%. | Conditional accounting: `1/(1-d) <= g < 1/(1-s)`. No demand response or Handle Layer energy reduction was measured. Revenue preservation does not prove profit preservation. |
| Aggregate illustration | `0.20 × 0.40 × 0.50 = 0.04`, or 4%. | Assumed adoption, energy share, and saving; not an estimate of global savings. Do not restore the original 10% claim. |
| IEA figures | 485 TWh for 2025 and approximately 950 TWh projected for 2030. | Data-centre totals, not a global AI-inference denominator. |
| Google measurement | Median Gemini Apps text prompt: 0.24 Wh in May 2025; narrower method: 0.10 Wh. | Product-specific provider measurement; boundary and sample differ. Neither is a universal prompt coefficient. |

The source ledger distinguishes measurements, projections, documentation, and illustrative calculations. Published productivity, context, memory, routing, and serving studies support individual mechanisms, not the combined protocol. Do not convert throughput gains into equal energy savings or practitioner impressions into effect sizes.

## Verification and next action

The supplement-access revision compiles to 19 pages with no LaTeX warnings or overfull boxes. Changed pages were rendered and visually inspected; the earlier pages retain the prior layout. The embedded ZIP matches the separate ZIP, all 28 reader-index links resolve, and all 28 payload checksums verify. The provisional-authorship note and the statement that no public URL or DOI has been assigned remain intact. These are document and packaging checks, not validation of the proposed system.

Current manuscript source SHA-256: `9fa7894c7ba521b106490ee0ad6aa5bbf3179f1990e6dae7507f1153e90f05f8`.

Current bibliography SHA-256: `3027ddc2459753169dc6d5fdab6f694413c7aff4287a87b4252326dab282daf1`.

**Authorized queue: empty after delivery.** Wait for the user's next instruction. Do not automatically expand the paper, run agents or experiments, contact authors, or submit/publish. If submission preparation is requested, resolve authorship/disclosures and journal requirements. If empirical validation is requested, turn Section 7 into a prespecified L/N/H study and collect actual task, human-effort, quality, cost, recovery, and energy data before making benefit claims.
