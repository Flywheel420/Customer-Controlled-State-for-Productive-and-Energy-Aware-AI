# Private project storage, history, and recovery

Design example for the manuscript, not a deployed system or experiment. All task, document, and checkpoint identifiers below are illustrative. No remote repository has been created or project data published.

## Required outcome

The customer can inspect, checkpoint, and restore the declared project recovery set without the bot project, provider login, or an inference call. Git is one implementation choice. Privacy, durable revisions, and offline recovery are requirements of this profile; use of a particular hosting company is not.

For a small project, keep the handle and small source documents directly in the private repository. A separate database or large-file service is not required simply to keep those files.

| Path or component | Purpose |
|---|---|
| `HANDLE.md` or `handle.json` | Current working state; earlier states remain in retained commits. |
| `source_index.json` | Source identity, version, date, file location, and claim relationships. |
| `sources/` | Small permitted source files needed for offline recovery. |
| `ledger/events.jsonl` | Explicit task, correction, supersession, execution, and outcome records. |
| `outputs/` | Drafts and accepted outputs, with status and evidence references. |
| `recovery_manifest.json` | Declared recovery files, checkpoint identifier, checksums, and any intentionally omitted dependencies. |
| Separate protected recovery copy | Versioned repository snapshot/bundle plus required external objects and restoration instructions. |

The project ledger documents events. It does not by itself coordinate simultaneous spending, prove the truth of source material, or provide an independently audited financial ledger. Those claims require separate controls.

## Illustrative corrected checkpoint

Human-readable checkpoint IDs stand in for actual revision identifiers in this example. Real implementations must resolve each reference and validate the revision relationship.

```json
{
  "schema": "illustrative-handle-profile-1",
  "project_id": "example-private-research",
  "revision_id": "checkpoint-002",
  "parent_revision_id": "checkpoint-001",
  "objective": "Prepare a sourced comparison using the correct reporting period.",
  "acceptance": [
    "Every material comparison identifies its reporting period.",
    "The corrected source is used consistently.",
    "An independent reviewer accepts the complete result."
  ],
  "state": "blocked",
  "sources": [
    {"id": "document-A", "version": "v2", "local_path": "sources/document-A-v2.txt"}
  ],
  "corrections": [
    {
      "id": "correction-001",
      "supersedes_claim": "claim-001",
      "reason": "The previous comparison used the wrong reporting period.",
      "invalidates_outputs": ["draft-001"],
      "invalidates_tasks": ["release-001"]
    }
  ],
  "queue": [
    {
      "id": "review-002",
      "status": "ready",
      "purpose": "Recheck the comparison against document-A v2.",
      "execution": "manual_or_authorized_model_call"
    }
  ],
  "policy_reference": "customer-policy-001",
  "wake_condition": "Authorized review is requested and required evidence is available.",
  "release_allowed": false
}
```

The earlier `checkpoint-001` remains available for historical inspection but is not automatically eligible to resume work after this correction. Restoring an older checkpoint is recovery of bytes, not authority to reinstate superseded conclusions.

## Save and recovery sequence

1. Start from a verified committed checkpoint and record its identifier. Keep the prior recovery snapshot.
2. Write the candidate handle, correction event, dependency changes, and source index through the authorized update path. Commit required source files too; uncommitted files are not protected merely because they are inside the working directory.
3. Check schema, reference resolution, source availability, and consistent invalidation. Mark semantic judgments as pending where human review is still required.
4. Durably store the checkpoint and condition advancement on the expected parent. If another writer advanced the project, retain the candidate separately for resolution; do not overwrite current state silently.
5. Generate or update the independent versioned recovery copy from committed state. Verify that its declared files can be restored. Preserve the previous good backup until the replacement is verified. A same-disk second folder does not protect against disk failure.
6. Only then apply the customer's retention policy. Updating the active `HANDLE.md` filename does not require deleting retained history. Do not give the bot unrestricted ability to erase the recovery copy.
7. If the bot fails while preparing `checkpoint-003`, restore the latest verified recoverable checkpoint into a fresh workspace. Its age and any later work lost must be reported; recovery is limited by the last successful checkpoint and backup.
8. Before resuming shared or paid work, reconcile later corrections and operation receipts where available. Recheck permissions, task claims, budgets, and source freshness. Keep outcomes marked unknown until resolved rather than retrying every uncertain action.

A standalone Git bundle can carry the required committed repository history without a running remote server. It does not automatically contain uncommitted files, runtime setup, credentials, or external source objects. A restore check must cover the complete declared recovery set. Credentials should be recovered through a protected facility, not stored in the repository for convenience.

## Small-project operating model

Use one active writer initially. The authorized customer can edit and correct records through that writer's update path. The supervisor can inspect an empty queue, wait, and write checkpoints without an LLM. It may run locally or in customer-controlled infrastructure, but a usable independent offline recovery copy must remain available to the customer.

When multiple workers are introduced, claim a task and reserve its permitted budget before invoking tools. Preserve an operation ID and execution receipt. Git conflicts after execution do not prevent duplicate work that has already occurred. Exactly-once external effects are not promised where the target service lacks the required retry contract.

## Proposed verification cases

Perform these only in disposable test copies, with synthetic records and no live side effects:

- Terminate a worker during candidate checkpoint creation; recover the last good revision.
- Make the bot workspace unavailable; restore from the protected copy without provider access.
- Remove a required external attachment from the recovery set; detect and report incomplete recovery.
- Reconnect two workers with competing task claims; prevent or detect duplicate execution and record any cost already incurred.
- Restore an old revision after a correction; block release of superseded conclusions.

Record restore success, recovery minutes, latest recoverable checkpoint age, missing files, repeated actions, storage bytes, transfer bytes, and human maintenance time. These tests are proposed, not reported as completed.

Includes confirmed and circumstantial data. Not financial advice.
